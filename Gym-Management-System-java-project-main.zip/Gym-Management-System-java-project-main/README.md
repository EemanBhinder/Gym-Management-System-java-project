# Gym-Management-System-java-project
Gym management system is a java based project with command line interface (CLI) . It's main purpose is to assist the gym management to keep track of the information about all the members , trainers and available inventory of equipment. It is easy to use and provides a user friendly experience to the user .
